require("dotenv").config();
const express = require("express");
var router = express.Router();
const validator = require("validator");
const path = require("path");
const bodyParser = require("body-parser");
var jwt = require("jsonwebtoken");

const app = express();



console.clear()
const publicDirectoryPath = path.join(__dirname, "../public");
app.set("views", path.join(__dirname, "../templates/views"));
app.set("view engine", "hbs");
app.use(express.static(publicDirectoryPath));


  app.use(express.json())

const post = [
  {
    name: "Anik",
    post: "Anik's Post",
  },
  {
    name: "Marcus",
    post: "Marcus's Post",
  },
];

router.get("/", (req, res) => {
  res.send('Hi this is node js for login click <a href="/login">here</a>');
});

router.get("/post", authenticateToken,(req, res) => {
    res.json(post.filter((el)=> req.user.name == el.name))
});

router.post("/login", (req, res) => {
    console.log(req.body)
  const username = req.body.username;
  const user = { name: username };

  const secretToken = jwt.sign(user, process.env.SECRET_KEY, {expiresIn:'5s'});
  res.json({"secreatToken":secretToken});
});


function authenticateToken (req,res,next){

const bearer = req.header('Authorization')
const token = bearer && bearer.split(" ")[1]
if(token == null) return res.status(401).send({error:"Please pass the Authorization"})

jwt.verify(token,process.env.SECRET_KEY,(err,user)=>{
if(err) return res.send(403).send(err)
req.user = user
next()
})


}
app.use(router);

app.listen(3001, () => {
  console.log("app is listening to 3001 port");
});
