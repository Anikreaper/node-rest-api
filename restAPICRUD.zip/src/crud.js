require("dotenv").config();
const express = require("express");
const validator = require("validator");
var jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const User = require("./database/user");
const Post = require("./database/post");
const readline = require("readline")
const {verifyUser,authorization} = require("./middleware/auth")



const app = express();


app.use(express.json())
console.clear()

app.post('/signup',async (req,res)=>{
    const {name, email, password} = req.body
    if(!validator.isEmail(email)) return res.status(400).json({"error":"Invalid Email"})
    if(password.length < 6) return res.status(400).json({"error":"Password Length should be > 6"})

    const newUser = {
        name,
        email,
        password:bcrypt.hashSync(password,8),
    }

    
    try {
    const user = await new User(newUser)
    await user.save()
    user.save().then((result)=> res.status(200).json({message:"Thanks for Sigining Up 😊"}))
  
    } catch (error) {
        res.status(403).json({error:error.message})
    }
    
   

    
})


app.post("/login",authorization,async (req,res)=>{

    const user = req.user
    const token = await jwt.sign(user,process.env.SECRET_KEY,{expiresIn: '15m'})


    res.status(200).json({
        'Token':token
    })

})



app.post("/post", verifyUser,async (req,res)=>{
    
    const user = req.user
    console.log(user)
  
    
     const post = await new Post ({author:user.id,...req.body})
     try {
       await post.save()
     } catch (error) {
        res.status(403).json({error:error.message})
     }

     post.save().then((result)=> res.status(200).json(result))
    
 
})




app.get('/getPostsByUser',verifyUser,async (req,res)=>{
    const user = req.user
   const posts = await Post.find({author:user.id})
  res.status(200).json(posts)
})



app.delete('/deletePost/:id?',verifyUser,async(req,res)=>{
    const user = req.user
    const postID = req.params.id || null
   

    if(postID != null) {
        try {
            const post =await  Post.findById(postID)
            console.log(user,post)
            if(post == null) return res.status(404.).json({error:"No Post Found ❌"})
            if(user.id.toString() === post.author){
                const deletedPost = await Post.deleteOne({_id:post._id})
                res.status(200).json(deletedPost)
            }else{
                res.status(403).json({message:"You are not the owner of this POST ❌" })
            }
        } catch (error) {
            res.status(404.).json({error:error.message})
        }
    }else{
     
        var rl = readline.createInterface(
            process.stdin, process.stdout);
            rl.question(`Do you want to delete all of your Post ${user.name}? (y/n)`, (opt) => {
                if(opt != 'y' && opt != 'n') return res.status(403).json({message:'Invalid User Input'})

                if(opt === 'n') return res.status(203).json({message:"Thanks for the Confirmation. We will not delete your Posts!😊"})
    
                if(opt === 'y'){
                    Post.deleteMany({author:user.id.toString()})
                    .then((deleted)=>res.status(200).json(deleted))
                }
            });
            rl.close()

           
           
            
    }
})


app.get("/myself",verifyUser,async(req,res)=>{
   res.status(200).json({user:req.user})
})


app.listen(3000, ()=>{
    console.log("Server Is running on port 3000")
})