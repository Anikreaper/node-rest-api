var jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const User = require("../database/user");

/* Middleware starts */

const  verifyUser = async(req, res, next)=>{
    const header = req.headers['authorization']
    const token = header && header.split(" ")[1]
    try {
     const user = jwt.verify(token, process.env.SECRET_KEY)
     req.user = user
     next()
    } catch (error) {
     res.status(403).json(error)
    }
    
    
 }
 
 
const authorization = async(req,res,next)=>{
 const {email,password} = req.body
 try {
 const getUser = await User.findOne({email})
 if(getUser == null) return res.status(404).json({"message": "No User Found 👤"})
 
 if(!bcrypt.compareSync(password, getUser.password)) return res.status(400).json({"message": "Incorrect Password 🔑"})
 
 req.user = {
     id: getUser._id.toString(),
     name:getUser.name,
     email:getUser.email
 }
 next()
 } catch (error) {
     res.status(403).json(error)
 }
 
 
 }
 
 /* The Middleware ends here */


 module.exports = {
    verifyUser,
    authorization
 }