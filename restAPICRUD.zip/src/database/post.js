const mongoose = require('./connect')

const postSchema = new mongoose.Schema({
    author:{
    },
    post_name:{
        type:String,
        required: true,
    },
    post_desc:{
        type:String,
        requird: true,
    }
    },{
        timestamps:true
    })

const Post = mongoose.model('Post', postSchema)

module.exports  = Post