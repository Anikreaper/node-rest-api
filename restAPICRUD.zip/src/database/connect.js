const { default: mongoose } = require("mongoose");

const options = {
  useNewUrlParser: true,
  autoIndex: true, //this is the code I added that solved it all
  keepAlive: true,
  connectTimeoutMS: 10000,
  socketTimeoutMS: 45000,
  family: 4, // Use IPv4, skip trying IPv6
  useUnifiedTopology: true
}
mongoose.set("strictQuery", false);
mongoose.connect('mongodb://127.0.0.1:27017/myapp-test',options)
  .then(() => true).catch((err)=> console.log(err));

  module.exports = mongoose